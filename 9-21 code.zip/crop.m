% Michael Omori
% Summer 2016

% This program crops the references and materials for each image and
% stores intensity information in the variable data

data = zeros(REFERENCES+1,nfiles);

% crops each image
for i=1:nfiles
    currentfilename = imagefiles(i).name;
    if nef ~= 1
        image = imread(currentfilename);
    else
        run rawIntensity
        image = lin_srgb;
    end
    
    if auto == 2
        sceneImage1 = image;
        sceneImage = rgb2gray(sceneImage1);
        scenePoints = detectSURFFeatures(sceneImage);
        [sceneFeatures, scenePoints] = extractFeatures(sceneImage, scenePoints);
        run auto_Croper
        
        crop_boundaries_all(:,:,i) = crop_boundaries;
    end
    for j=1:REFERENCES+1
        % thorough method auto
        if auto == 2 && i > 1
            cropped_image = imcrop(image, crop_boundaries_all(j,:,i));
            bad = 0;
        % check values, if difference between current and previous average
        % values is greater than 20% then sample again
            while bad < 2
                data(j,i) = mean(mean(mean(cropped_image)));
                if abs(data(j,i) - mean(data(j,1:i-1))) / mean(data(j,1:i-1)) > 0.2 || ~(data(j,i) > 0)...
                        || abs(data(j,i) - mean(data(j,1:i-1))) > 10
                    bad = bad + 1;
                    %display('bad value')
                    %display(i)
                else
                    bad = bad + 5;
                end
                % try auto using previous averaged locations
                if bad == 1
                    first = mean(crop_boundaries_all(j,1,1:i-1));
                    second = mean(crop_boundaries_all(j,2,1:i-1));
                    third = mean(crop_boundaries_all(j,3,1:i-1));
                    fourth = mean(crop_boundaries_all(j,4,1:i-1));
                    crop_boundaries_all(j,:,i) = [first,second,third,fourth];
                    cropped_image = imcrop(image, crop_boundaries_all(j,:,i));                
                 % try manual if auto fails 2nd time
                elseif bad == 2
                    display('auto try 2 failed')
                    msg = msgbox(sprintf('crop value %d', j));
                    [~, rect] = imcrop(sceneImage1);
                    delete(msg);
                    crop_boundaries_all(j,:,i) = rect;
                    cropped_image = imcrop(image, crop_boundaries_all(j,:,i));
                end
            end 
        % normal methods
        elseif auto == 2 && i == 1
            cropped_image = imcrop(image, crop_boundaries_all(j,:,i));
        % check values, if bad, sample again
            data(j,i) = mean(mean(mean(cropped_image)));
            if abs(data(j,i) - mean(data(j,1:i-1))) > 2 || ~(data(j,i) > 0)...
                    || abs(data(j,i) - mean(data(j,1:i-1))) > 10
                %display('bad value')
                %display(i)
                [~, rect] = imcrop(sceneImage1);
                delete(msg);
                crop_boundaries_all(j,:,i) = rect;
            end
        else
            cropped_image = imcrop(image, crop_boundaries(j,:));
        end
        data(j,i) = mean(mean(mean(cropped_image)));
    end
end