% Michael Omori
% Summer 2016

% This program takes in a folder of images and outputs a spreadsheet of 
% the intensities of each material scaled to references.

% computer vision and neural network toolbox needed
% use can change constants in all caps
% 1 for automatic: automatically find initial crop locations
% 0 for manual: manual find initial crop locations
% 2 for thorough auto: automatically find crop locations in each image

warning('off', 'all');

tic

% constants
REFERENCES = 10;
% reflectance values for gray scale cards
ACTUAL = [6,11,23,33.5,45.8,58.2,70.2,82.6,94.6,110.6]; 

crop_boundaries = zeros(REFERENCES+1, 4);

% references should be named with these numbers in front
nef = input('1 for dng, 0 for JPG, 2 for TIF ');
imaging = input('1 for nikon, 0 for iPhone ');
if nef == 0
    imagefiles = dir('**.JPG');
elseif nef == 1
    imagefiles = dir('**.dng');
    currentfilename = imagefiles(1).name;
    run rawIntensity
    sceneImage1 = lin_srgb;
else
    imagefiles = dir('**.TIF');
end

nfiles = length(imagefiles);

if nef ~= 1
    currentfilename = imagefiles(1).name;
    sceneImage1 = imread(currentfilename);
end

auto = input('1 for auto, 0 for manual, 2 for thorough auto ');

% extract features from the first image to use in image detection

if auto == 1
    sceneImage = rgb2gray(sceneImage1);
    scenePoints = detectSURFFeatures(sceneImage);
    [sceneFeatures, scenePoints] = extractFeatures(sceneImage, scenePoints);
    run auto_Croper
elseif auto == 0
    run CROPer.m
else
    crop_boundaries_all = zeros(REFERENCES+1, 4, nfiles);
end

run crop
run scaled

toc