% Michael Omori
% Summer 2016

% This program sets up the automatic cropping using object detection.

% constants
CROP_C = 12;

% 10 reference crops and 1 material crop using crop_rect
% xmin, ymin, width, height

for a=1:REFERENCES
    name = sprintf('%d%dvalue%d.png', nef,imaging,a);
    boxImage1 = imread(name);
    try
        run objectDetection
        xmin = crop_rect(1) + crop_rect(3) / 2;
        %find crop dimensions
        if a <= 5
        %card pointing up
        ymin = crop_rect(2) + crop_rect(4) * 7 / CROP_C;
        else
        %card pointing down
        ymin = crop_rect(2) + crop_rect(4) * 3 / CROP_C;
        end
        crop_size = crop_rect(3) / CROP_C;
        %crop_size = 50;
    catch
        xmin = mean(crop_boundaries_all(a,1,1:i-1));
        ymin = mean(crop_boundaries_all(a,2,1:i-1));
        crop_size = mean(crop_boundaries_all(a,3,1:i-1));
    end
    crop_boundaries(a, :) = [xmin, ymin, crop_size, crop_size];
end

crop_rect(1) = crop_rect(1) + crop_rect(3) * 2.3;
crop_rect(3) = crop_size * 2.5;
crop_rect(4) = crop_size * 2.5;
crop_boundaries(REFERENCES+1,:) = crop_rect;

close all;